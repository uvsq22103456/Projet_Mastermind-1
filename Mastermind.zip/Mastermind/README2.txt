Le premier joueur défini la combinaison en cliquant sur les boutons de couleurs, il peut supprimer le dernier element
choisi en cliquant sur le bouton rouge ou la valider en cliquant sur le bouton valider en vert.

Ensuite c'est au tour du second joueur d'essayer le jeu, il a dix tentatives pour deviner.
Pour entrer sa proposition, il doit faire la même manipulation que le joueur 1 et valider.
Sa proposition s'affiche sur l'écran avec à droite des indications (carrés vert et gris).
S'il y en a aucun c'est qu'aucune des couleurs sélectionnée est la bonne.
Les carrés vert représentes le nombre de carrés bien placés, les carrés gris, les bonnes couleurs mais placé dans 
le mauvais ordre.

Ainsi 4 carrés vert signifient que le joueur 2 a gagné.